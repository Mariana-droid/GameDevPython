from item import Item

lighter = Item("lighter")
lighter.set_description("A small lighter. In the side it is engraved with some initials: F.G. You give it a experimental flick and it lights up\n\
beautifully.")

screwdriver = Item("screwdriver")
screwdriver.set_description("A screwdriver with a blue handle.")