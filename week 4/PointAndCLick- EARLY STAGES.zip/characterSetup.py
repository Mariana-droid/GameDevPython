from character import Character
from dialogueSetup import *
Joana = Character("Joana")
Joana.set_firstConversation(FirstTimeTalkingJ)
Joana.set_conversation(HelloJ)


